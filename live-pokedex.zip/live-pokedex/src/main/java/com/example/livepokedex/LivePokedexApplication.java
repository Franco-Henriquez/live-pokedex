package com.example.livepokedex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivePokedexApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivePokedexApplication.class, args);
	}

}
